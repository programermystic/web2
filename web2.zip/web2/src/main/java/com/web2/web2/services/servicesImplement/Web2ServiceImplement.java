package com.web2.web2.services.servicesImplement;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web2.web2.model.filial;
import com.web2.web2.model.funcionarios;
import com.web2.web2.repository.web2repository;
import com.web2.web2.services.blogWeb2Services;
@Service
public class Web2ServiceImplement  implements blogWeb2Services{
	@Autowired
	web2repository blogWeb2Repository;
	
	
	
	
	@Override
	public List<filial> findFilialByNomeLike(String nome){
		return blogWeb2Repository.findFilialByNomeLike(nome);
	}
	
	@Override
	public List<filial> findFilialByCidadeLike(String cidade){
		return blogWeb2Repository.findFilialByCidadeLike(cidade);
	}

	@Override
	public filial findById(long id) {
		// TODO Auto-generated method stub
		return blogWeb2Repository.findById(id).get();
	}

	@Override
	public filial save(filial filial) {
		// TODO Auto-generated method stub
		return blogWeb2Repository.save(filial);
	}

	@Override
	public filial deleteById(long id) {
		// TODO Auto-generated method stub
		return deleteById(id);
	}

	@Override
	public List<filial> findAll() {
		// TODO Auto-generated method stub
		return blogWeb2Repository.findAll();
	}

	

}
