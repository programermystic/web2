package com.web2.web2.services;
import java.util.List;

import com.web2.web2.model.filial;
import com.web2.web2.model.funcionarios;
public interface blogWeb2Services2 {
List<funcionarios> findAll();
funcionarios save(funcionarios funcionarios);
List<funcionarios> findFuncionariosByIdfilial(long idfilial);
funcionarios deleteById(long id);
funcionarios findById(long id);
List<funcionarios> findFuncionariosByNomeLike(String nome);

}
