package com.web2.web2.model;



import javax.persistence.*;

import javax.validation.constraints.NotBlank;

import com.sun.istack.NotNull;



@Entity 
@Table(name="funcionarios")
public class funcionarios {

	@Id
	
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 private long id;
	
	 @NotBlank
	 private String nome;
	 @NotBlank
	 private String email;
	 @NotBlank
	 private String telefone;
	 @NotBlank
	 private String setor;
	 @NotNull
	 private long idfilial;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getSetor() {
		return setor;
	}
	public void setSetor(String setor) {
		this.setor = setor;
	}
	public long getIdfilial() {
		return idfilial;
	}
	public void setIdfilial(long idfilial) {
		this.idfilial = idfilial;
	}
	
	
	
	
	
}