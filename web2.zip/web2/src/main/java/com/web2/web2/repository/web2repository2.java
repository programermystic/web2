package com.web2.web2.repository;
import java.util.List;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.web2.web2.model.funcionarios;


public interface web2repository2 extends JpaRepository<funcionarios,Long>{


	List<funcionarios> findFuncionariosByIdfilial(long idfilial);

	List<funcionarios> findFuncionariosByNomeLike(String nome);

}
