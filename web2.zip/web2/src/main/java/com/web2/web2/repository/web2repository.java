package com.web2.web2.repository;

import java.util.List;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.web2.web2.model.filial;


public interface web2repository extends JpaRepository<filial,Long>{


	List<filial> findFilialByNomeLike(String nome);
	List<filial> findFilialByCidadeLike(String cidade);

}
