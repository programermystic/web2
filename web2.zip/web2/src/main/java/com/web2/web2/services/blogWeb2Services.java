package com.web2.web2.services;
import java.util.List;

import com.web2.web2.model.filial;
import com.web2.web2.model.funcionarios;
public interface blogWeb2Services {
List<filial> findAll();
filial findById(long id);
filial save(filial filial);
//List<filial> findFilialByTipo(int tipo);
filial deleteById(long id);
List<filial> findFilialByNomeLike(String nome);
List<filial> findFilialByCidadeLike(String cidade);

}
