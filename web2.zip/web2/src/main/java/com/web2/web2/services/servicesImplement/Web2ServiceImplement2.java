package com.web2.web2.services.servicesImplement;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web2.web2.model.filial;
import com.web2.web2.model.funcionarios;
import com.web2.web2.repository.web2repository2;
import com.web2.web2.services.blogWeb2Services2;
@Service
public class Web2ServiceImplement2  implements blogWeb2Services2{
	@Autowired
	web2repository2 blogWeb2Repository2;
	

	@Override
	public funcionarios findById(long id) {
		// TODO Auto-generated method stub
		return blogWeb2Repository2.findById(id).get();
	}

	@Override
	public List<funcionarios> findAll() {
		// TODO Auto-generated method stub
		return blogWeb2Repository2.findAll();
	}

	@Override
	public funcionarios save(funcionarios funcionarios) {
		// TODO Auto-generated method stub
		return blogWeb2Repository2.save(funcionarios);
	}

	@Override
	public funcionarios deleteById(long id) {
		// TODO Auto-generated method stub
		return deleteById(id);
	}

	@Override
	public List<funcionarios> findFuncionariosByIdfilial(long idfilial) {
		return blogWeb2Repository2.findFuncionariosByIdfilial(idfilial);
	}

	@Override
	public List<funcionarios> findFuncionariosByNomeLike(String nome){
		return blogWeb2Repository2.findFuncionariosByNomeLike(nome);
	}

	

}
