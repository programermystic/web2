package com.web2.web2.controller;

import org.springframework.beans.factory.annotation.Autowired;




import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import com.web2.web2.model.filial;
import com.web2.web2.model.funcionarios;
import com.web2.web2.repository.web2repository;
import com.web2.web2.repository.web2repository2;

@Controller
public class blogweb2controller {

	@Autowired
	web2repository web2repository;
	
	@RequestMapping(value="/filiais",method=RequestMethod.GET)
	public ModelAndView getfilial(){
		ModelAndView mv= new ModelAndView("filiais");
		List<filial> filial = web2repository.findAll();
		mv.addObject("filiais",filial);
		return mv;
	}

	@RequestMapping(value="/filial/{id}",method=RequestMethod.GET)
	public ModelAndView getfilial(@PathVariable("id") long id) {
		ModelAndView mv = new ModelAndView("filial");
		Optional <filial> filial = web2repository.findById(id);
		mv.addObject("nome",filial.get().getNome());
		mv.addObject("email",filial.get().getEmail());
		mv.addObject("telefone",filial.get().getTelefone());
		mv.addObject("cidade",filial.get().getCidade());
		return mv;
	}
	
	

	@RequestMapping(value="/principal",method=RequestMethod.GET)
	public String principal() {
		return "principal";
	}
	@RequestMapping(value="/nueva_filial",method=RequestMethod.GET)
	public String nueva_filial() {
		return "nueva_filial";
	}
	

	@RequestMapping(value="/nueva_filial",method=RequestMethod.POST)
	public String saveFilial(@Valid filial filial,BindingResult result,RedirectAttributes attributes) {
		if(result.hasErrors())
		{
			attributes.addFlashAttribute("mensaje","verifique los campos obligatorios...");
			return "redirect:/nueva_filial";
		}
	
		web2repository.save(filial);
		return "redirect:/filiais";
	}
	
	
	@RequestMapping(value="/filiais/delete/{id}",method=RequestMethod.GET)
	public String deleteFilial(@PathVariable("id") long id,RedirectAttributes attributes) {
		web2repository.deleteById(id);
		 attributes.addFlashAttribute("mensaje", "Borrado con Exito...");
		 return "redirect:/filiais";
	}
	@RequestMapping(value="/filiais/update_filial/{id}",method=RequestMethod.GET)
	public ModelAndView updatefilial(@PathVariable("id") long id) {
		ModelAndView mv = new ModelAndView("update_filial");
		Optional <filial> filial = web2repository.findById(id);
		mv.addObject("nome",filial.get().getNome());
		mv.addObject("email",filial.get().getEmail());
		mv.addObject("telefone",filial.get().getTelefone());
		mv.addObject("cidade",filial.get().getCidade());
		return mv;
	}
	@RequestMapping(value="/filiais/update_filial/{id}",method=RequestMethod.POST)
	public String updatefilial(filial filial) {
		filial filialexistente= web2repository.findById(filial.getId()).orElse(null);
		filialexistente.setNome(filial.getNome());
		filialexistente.setEmail(filial.getEmail());
		filialexistente.setTelefone(filial.getTelefone());
		filialexistente.setCidade(filial.getCidade());
		web2repository.save(filialexistente);
		
	
		return "redirect:/filiais";
	}
	
	@RequestMapping(value="**/pesquisar",method=RequestMethod.POST)
	public ModelAndView getFilialByNomeLike(@RequestParam("pesquisar") String pesquisar) {
		ModelAndView mv = new ModelAndView("filiais");
		List<filial> filial = web2repository.findFilialByNomeLike("%"+pesquisar+"%");
		mv.addObject("filiais",filial);
		return mv;
	}
	
	@RequestMapping(value="**/pesquisarcidade",method=RequestMethod.POST)
	public ModelAndView getFilialByCidadeLike(@RequestParam("pesquisarcidade") String pesquisarcidade) {
		ModelAndView mv = new ModelAndView("filiais");
		List<filial> filial = web2repository.findFilialByCidadeLike("%"+pesquisarcidade+"%");
		mv.addObject("filiais",filial);
		return mv;
	}
	
	@Autowired
	web2repository2 web2repository2;
	
	@RequestMapping(value="**/buscar",method=RequestMethod.POST)
	public ModelAndView getFuncionariosByNomeLike(@RequestParam("buscar") String buscar) {
		ModelAndView mv = new ModelAndView("funcionarios");
		List<funcionarios> funcionarios = web2repository2.findFuncionariosByNomeLike("%"+buscar+"%");
		mv.addObject("funcionarios",funcionarios);
		return mv;
	}
	@RequestMapping(value="/funcionarios",method=RequestMethod.GET)
	public ModelAndView getfuncionarios(){
		ModelAndView mv= new ModelAndView("funcionarios");
		List<funcionarios> funcionarios = web2repository2.findAll();
		mv.addObject("funcionarios",funcionarios);
		return mv;
	}
	
	
	@RequestMapping(value="/funcionario/{id}",method=RequestMethod.GET)
	public ModelAndView getfuncionario(@PathVariable("id") long id) {
		ModelAndView mv = new ModelAndView("funcionario");
		Optional <funcionarios> funcionario = web2repository2.findById(id);
		mv.addObject("nome",funcionario.get().getNome());
		mv.addObject("email",funcionario.get().getEmail());
		mv.addObject("telefone",funcionario.get().getTelefone());
		mv.addObject("setor",funcionario.get().getSetor());
		mv.addObject("idfilial",funcionario.get().getIdfilial());
		return mv;
	}
	@RequestMapping(value="/nuevo_funcionario",method=RequestMethod.GET)
	public String nuevo_funcionario() {
		return "nuevo_funcionario";
	}
	

	@RequestMapping(value="/nuevo_funcionario",method=RequestMethod.POST)
	public String saveFuncionario(@Valid funcionarios funcionario,BindingResult result,RedirectAttributes attributes) {
		if(result.hasErrors())
		{
			attributes.addFlashAttribute("mensaje","verifique los campos obligatorios...");
			return "redirect:/nuevo_funcionario";
		}
	
		web2repository2.save(funcionario);
		return "redirect:/funcionarios";
	}
	
	
	
	@RequestMapping(value="/funcionarios/delete_funcionario/{id}",method=RequestMethod.GET)
	public String deleteFuncionario(@PathVariable("id") long id,RedirectAttributes attributes) {
		web2repository2.deleteById(id);
		 attributes.addFlashAttribute("mensaje", "Borrado con Exito...");
		 return "redirect:/funcionarios";
	}
	@RequestMapping(value="/funcionarios/update_funcionario/{id}",method=RequestMethod.GET)
	public ModelAndView updatefuncionario(@PathVariable("id") long id) {
		ModelAndView mv = new ModelAndView("update_funcionario");
		Optional <funcionarios> funcionario = web2repository2.findById(id);
		mv.addObject("nome",funcionario.get().getNome());
		mv.addObject("email",funcionario.get().getEmail());
		mv.addObject("telefone",funcionario.get().getTelefone());
		mv.addObject("setor",funcionario.get().getSetor());
		mv.addObject("idfilial",funcionario.get().getIdfilial());
		return mv;
	}
	@RequestMapping(value="/funcionarios/update_funcionario/{id}",method=RequestMethod.POST)
	public String updatefuncionario(funcionarios funcionario) {
		funcionarios funcionarioexistente= web2repository2.findById(funcionario.getId()).orElse(null);
		funcionarioexistente.setNome(funcionario.getNome());
		funcionarioexistente.setEmail(funcionario.getEmail());
		funcionarioexistente.setTelefone(funcionario.getTelefone());
		funcionarioexistente.setSetor(funcionario.getSetor());
		funcionarioexistente.setIdfilial(funcionario.getIdfilial());
		web2repository2.save(funcionarioexistente);
		
	
		return "redirect:/funcionarios";
	}
	
	

	
	@RequestMapping(value="/funcionarios/idfilial/{id}",method=RequestMethod.GET)
	public ModelAndView getFuncionariosByIdfilial(@PathVariable("id") long id) {
		ModelAndView mv = new ModelAndView("funcionarios");
		List<funcionarios> funcionarios= web2repository2.findFuncionariosByIdfilial(id);
		mv.addObject("funcionarios",funcionarios);
		return mv;
	}
}

